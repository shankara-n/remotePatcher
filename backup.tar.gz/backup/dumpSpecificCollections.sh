#!/bin/bash
colls=( tracker_data plant_data flood_sensor_settings heartBeatSettings version_number big_query_settings currently_issued_stow last_pushed_time_stamps ethernet_settings wind_sensor_settings zone_data snow_sensor_settings time_zone request_frequency sensors next_periodic_request historical_data )

for c in ${colls[@]}
do
  mongodump -d voyagerDB -c $c
done
