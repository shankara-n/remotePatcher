#!/bin/bash
cat /etc/mongodb.conf | grep journal=
