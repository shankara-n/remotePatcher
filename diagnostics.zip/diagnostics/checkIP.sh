#!/bin/bash
ip addr | grep inet
